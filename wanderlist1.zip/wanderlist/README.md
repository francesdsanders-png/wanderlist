# WanderList Setup Guide

## What you need (all free)
- GitHub account → github.com
- Supabase account → supabase.com
- Vercel account → vercel.com

---

## Step 1 — Set up your Supabase database

1. Go to **supabase.com** and create a free account
2. Click **New Project**, give it a name (e.g. "wanderlist"), set a password, click Create
3. Wait ~2 minutes for it to spin up
4. In the left sidebar, click **SQL Editor**
5. Paste this SQL and click **Run**:

```sql
create table places (
  id uuid default gen_random_uuid() primary key,
  created_at timestamp with time zone default now(),
  name text not null,
  location text,
  distance text,
  cost text,
  website text,
  phone text,
  link text,
  description text,
  tags text[],
  status text default 'Undecided'
);

alter table places enable row level security;

create policy "Allow all" on places for all using (true);
```

6. Go to **Project Settings → API**
7. Copy your **Project URL** and **anon public** key
8. Open `src/supabase.js` and paste them in:

```js
const SUPABASE_URL = 'https://your-project.supabase.co'
const SUPABASE_ANON_KEY = 'eyJ...'
```

---

## Step 2 — Upload to GitHub

1. Go to **github.com** → click the **+** → **New repository**
2. Name it `wanderlist`, keep it Public, click **Create repository**
3. On the next screen, click **uploading an existing file**
4. Drag ALL the files from this zip into the upload area (keep the folder structure)
5. Click **Commit changes**

---

## Step 3 — Deploy on Vercel

1. Go to **vercel.com** → sign in with your GitHub account
2. Click **Add New Project**
3. Find your `wanderlist` repository and click **Import**
4. Leave all settings as default — Vercel detects Vite automatically
5. Click **Deploy**
6. In ~2 minutes you'll get a live URL like `wanderlist-frances.vercel.app` 🎉

---

## Step 4 — Add to your home screen (iPhone)

1. Open your Vercel URL in **Safari**
2. Tap the **Share** button (box with arrow)
3. Tap **Add to Home Screen**
4. Tap **Add**

It will open full screen like a real app. Share the same URL with your partner and you'll both see the same list in real time!

---

## Troubleshooting

**"Couldn't connect to database"** → Double-check your URL and key in `src/supabase.js`

**Vercel build fails** → Make sure all files are uploaded including `package.json` and `vite.config.js`

**Changes not showing for partner** → Refresh the page; real-time sync requires the browser tab to be open
