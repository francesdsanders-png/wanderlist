import { createClient } from '@supabase/supabase-js'

// ─────────────────────────────────────────────────────────────
// STEP 1: Go to https://supabase.com and create a free account
// STEP 2: Create a new project
// STEP 3: Go to Project Settings → API
// STEP 4: Copy your Project URL and anon/public key and paste below
// ─────────────────────────────────────────────────────────────

const SUPABASE_URL = 'https://eumqfazzjeuvwgdecxyr.supabase.co'       // e.g. https://abcdef.supabase.co
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV1bXFmYXp6amV1dndnZGVjeHlyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzcxMzI1NDcsImV4cCI6MjA5MjcwODU0N30.7SozbIwiRxUMa9g-LUlj72eOILdYu3ZBpVmLSrOXmR8'  // starts with eyJ...

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
